echo "installing sendcm tools..."
./install-step_2.sh

