echo "Updating sendcm tools..."
./uninstall-step_2.sh
./install-step_2.sh