echo "Removing sendcm tools..."
sudo rm -rf /etc/sendcmtools/;
sudo rm /bin/sendcmtool;
sudo rm /bin/uploadsendcm;
sudo rm /bin/downloadsendcm;