echo "Removing sendcm tools..."
./uninstall-step_2.sh