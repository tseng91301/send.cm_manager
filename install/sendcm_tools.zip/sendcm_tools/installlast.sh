rm ~/.sendcmtools/file/test.txt
rm ~/.sendcmtools/tmp/test.txt